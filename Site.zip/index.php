<?php
$p='Сегодня ';
$d=date('d/m/Y');
$name='Чебурашка';
$surname='Геннадьевна';
$city='HAKER-4';
$age='95';
?>
<?php
include 'main.php';
?>
