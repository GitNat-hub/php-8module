<div class="logoImg">
<?php
    echo '<img src="img/php-trans.gif">';
?>
</div>
