<!DOCTYPE=html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <META NAME="" content="width=device-width, initial-scale=1.0">
    <title> Практическое задание на PHP </title>
    <link rel="stylesheet" href="Style.css" />
</head>
<body>
    <div class="flex-conteiner">
        <div class="header">
          <?php include 'logo.inc.php' ?>
          <?php include 'menu.inc.php' ?>
        </div>
        <div class="about_me">
            <h2> <?php echo $p, $d ?></h2>
            <div class="data">
                <div class="myImg">
                    <?php echo '<img src="img/php.jpg" width="150" >'; ?>
                </div>
                <div class="fullname">
                    <ol>
                        <il> <b>Практическая работа студентки:</b></il>
                        <il><?php echo $name,' ',$surname,' ' ?></il>
                    </ol>
                    <ol>
                        <il><b>Группа: </b></il>
                        <il><?php echo $city ?></il>
                    </ol>
                    <ol>
                        <il><B>Возраст: </b></il>
                        <il><?php echo $age,' лет' ?></il>
                    </ol>
                </div>
            </div>
            <hr width="450" color="gray" align="left">
            <div class="knowledge">
                <?php include 'knowledge.inc.php'; ?>
                <?php
                echo $dprice;
                ?> <br><br>
                <?php echo $a,' ',$b,' ',$c; ?>
                <?php
                $a = 10;
                $b = 20;
                $c = $a + $b;
                echo 'Сумма переменных $a и $b равна '.$c.'.';
                ?>
            </div>
            <hr width="450" color="gray" align="left">

            <div class="text">
                    Введте число:
            <form>
                <div class="search">
                    <input type="search" name="q">
                    <input type="submit" value="OK">
                </div>
            </form>
            <?php
            $f = isset($_REQUEST['q']) ? $_REQUEST['q'] : '';
            $f = preg_replace("/[^,.0-9]/", '', $f);
            if (preg_match_all("/\d/",$f)) {
                $f = (float) $f;
                $sum = $age*$f;
                print('Возраст * '.$f.' = '.$sum);
            }
            else {
                echo 'число не обнаружено :(';
            }
            ?>
            </div>
        </div>
        <?php include 'footer.inc.php' ?>
    </div>
</body>
</html>
